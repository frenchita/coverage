const calculadora = require("./src/calculadora")

console.log(calculadora.sumar(2,3))
console.log(calculadora.restar(5,3))
console.log(calculadora.dividir(60,3))
console.log(calculadora.multiplicar(7,8))
console.log(calculadora.promedio(10,20))